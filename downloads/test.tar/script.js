const http = require('k6/http');
const k6 = require('k6');
import { check, sleep } from 'k6';
import { SharedArray } from 'k6/data';

// API endpoint for user registration
var url='https://test-api.k6.io/public/crocodiles/'

// Test configuration options
export const options = {
  // Include various percentile stats in the summary
  summaryTrendStats: ['avg', 'min', 'med', 'max', 'p(90)', 'p(95)', 'p(99)'],
  scenarios: {
    s1: {
      // Use constant arrival rate for load testing
      executor: 'constant-arrival-rate',
      // Parameters passed through environment variables
      rate: `${__ENV.rate}`,
      exec: "register_user",
      timeUnit: '1s',
      duration: `${__ENV.duration}`,
      maxVUs: `${__ENV.maxuv}`, 
      preAllocatedVUs: `${__ENV.prevu}`,
    },
},
};

// Configure test summary output format
export function handleSummary(data) {
  return {
    'stdout': JSON.stringify(data),
  };
}

// Load users data from JSON file
const user_list = new SharedArray('users', function() {
    return JSON.parse(open('./users.json'));
});

// Main function to register users
export function register_user() {
    // Get user data based on virtual user and iteration
    const userData = user_list[__VU * __ITER % user_list.length];
   
    const user = userData["id]
  
    url=url+user
    // Send POST request to register endpoint
    var res = http.get(url, {
      headers: {
        'Content-Type': 'application/json'
        }
        });

    // Verify response status code
    const isStatus200 = check(res, {
      'is status 200': (r) => r.status === 200,
    });

    // Log errors if registration fails
    if (!isStatus200) {
        console.error(`Unexpected status code: ${res.status}`);
        console.error(user);
        console.error(password);
        console.error(res);
    }
}
